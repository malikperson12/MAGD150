function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(51);
  
  noStroke();
colorMode(HSB, 400);
for (let i = 0; i < 400; i++) {
  for (let j = 0; j < 400; j++) {
    stroke(i, j, 400);
    point(i, j);
  }
}
  
  noStroke();
colorMode(RGB, 300);
for (let i = 0; i < 300; i++) {
  for (let j = 0; j < 300; j++) {
    stroke(i, j, 0);
    point(i, j);
  }
}
 
  let c = color(400, 190, 0);
fill(c);
noStroke();
ellipse(100, 100, 325, 325); // Draw Sun
// Using only one value generates a grayscale value.
c = color(65, 150, 0);
fill(c);

ellipse(300, 300, 150, 150); // Draw Mercury
  
  c=color (400,240,0);
  fill(c);
  arc(350, 175, 80, 80, 1100, PI + QUARTER_PI, PIE); //moon
  
  
quad(0, 0, 235, 15, 225, 190, 30, 240); //sun aesthetic
}