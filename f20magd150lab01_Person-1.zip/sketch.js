function setup() { createCanvas(400, 400); }
function draw() { background(75); 
                 rect(50, 195, 100, 200); 
                 // rect(x, y, width, height) 
                 rect(150, 195, 100, 200); // rect(x, y, width, height) 
                 line(180, 350, 180, 395); // line(x1, y1, x2, y2) Left line 
                 line(220, 350, 220, 395); // line(x1, y1, x2, y2) Right Line 
                 line(180, 350, 220, 350); // line(x1, y1, x2, y2) Top line
                 line(200, 350, 200, 395); // line(x1, y1, x2, y2) Middle Line 
                 strokeWeight(3.0); 
                 strokeCap(SQUARE); 
                 ellipse(200,250,75,75); 
                 noFill(); ellipse(100,250,75,75); 
                 point(195, 375); // point(x, y) door knob left point(205, 375); // point(x, y) door knob right
                }