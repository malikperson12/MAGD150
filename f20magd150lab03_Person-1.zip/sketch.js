
let i = 0; 
  
function setup(){
  createCanvas(400, 400);
  rectMode(CENTER);
  print(5+8.37*3);
print(80.8-4/2);
  print(min(3,7) + max(4,8));
  

  
}
function draw(){
  
  background(150);
  
  if (i==1){
   //light blue bubble
    
    fill(0, 300, 400);
    
    let x1 = map(mouseX, 0, width, 150, 250, true);
      let x2 = map(mouseY, 0, width, 150, 250, true);
      let x3 = map(pmouseX, 0, width, 150, 250, true);
      
    
  ellipse(x1, 200, 250, 250);
  ellipse(x2, 200, 225, 225);
    ellipse(x3, 125, 25, 25);
    
     text(nf(3.3),55,55);
    
  }
  
  
  else if (i > 1){
    //medium blue bubble
    
    fill(0, 200, 400);
    
      let x1 = map(mouseX, 0, width, 150, 250, true);
      let x2 = map(mouseY, 0, width, 150, 250, true);
      let x3 = map(pmouseX, 0, width, 150, 250, true);
      
    
  ellipse(x1, 200, 250, 250);
  ellipse(x2, 200, 225, 225);
    ellipse(x3, 125, 25, 25);
    
      text(nf(5.5),55,55);
  
  }
  
  
  else if (i < 1){
    //dark blue bubble
    
    
    fill(0, 100, 400);
      
  let x1 = map(mouseX, 0, width, 150, 250, true);
  let x2 = map(mouseY, 0, width, 150, 250, true);
  let x3 = map(pmouseX, 0, width, 150, 250, true);
      
    
  ellipse(x1, 200, 250, 250);
  ellipse(x2, 200, 225, 225);
  ellipse(x3, 125, 25, 25);
    
     text(nf(7.7),55,55);
    
  }

  
}