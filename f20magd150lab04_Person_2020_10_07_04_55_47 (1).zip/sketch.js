
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  if (mouseIsPressed === true  ){
  
  fill(235, 176, 66)
  
    ellipse(150, 150, 120, 120); // crust
  
  fill(235, 210, 101);
  
  ellipse (150, 150, 100, 100); //cheese
  
  
  var x = 125;
  while (x <= 175){
    
    fill(235, 89, 42);
     ellipse( x , 125,15,15);
    
    x = x+ 25;
  } //first row of toppings
  
  
  var x = 112;
  while (x <= 200){
    fill(235, 89, 42);
     ellipse( x , 150,15,15);
    
    x = x+ 25;
  } // second row of pizza toppings
  
    
   var x = 125;
  while (x <= 175){
    fill(235, 89, 42);
     ellipse( x , 175,15,15);
    
    x = x+ 25;
  } // third row of pizza toppings 
  ////////////////////////////////////////////
  } // end if and move to else if
  
   if (keyIsPressed === true) 
  {
    
    
  fill(235, 176, 66)
  
    ellipse(300, 150, 120, 120); // crust
  
  fill(235, 210, 101);
  
  ellipse (300, 150, 100, 100); //cheese
  
  
  var x = 275;
  while (x <= 325){
    
    fill(235, 89, 42);
     ellipse( x , 125,15,15);
    
    x = x+ 25;
  } //first row of toppings
  
  
  var x = 262;
  while (x <= 350){
    fill(235, 89, 42);
     ellipse( x , 150,15,15);
    
    x = x+ 25;
  } // second row of pizza toppings
  
    
   var x = 275;
  while (x <= 325){
    fill(235, 89, 42);
     ellipse( x , 175,15,15);
    
    x = x+ 25;
  } // third row of pizza toppings 
    
    
  }// end  if
  ////////////////////////////////////
  if ( mouseIsPressed && keyIsPressed === true) 
   {
    
    
  fill(235, 176, 66)
  
    ellipse(225, 275, 120, 120); // crust
  
  fill(235, 210, 101);
  
  ellipse (225, 275, 100, 100); //cheese
  
  
  var x = 200;
  while (x <= 250){
    
    fill(235, 89, 42);
     ellipse( x , 250,15,15);
    
    x = x+ 25;
  } //first row of toppings
  
  
  var x = 187;
  while (x <= 275){
    fill(235, 89, 42);
     ellipse( x , 275,15,15);
    
    x = x+ 25;
  } // second row of pizza toppings
  
    
   var x = 200;
  while (x <= 250){
    fill(235, 89, 42);
     ellipse( x , 300,15,15);
    
    x = x+ 25;
  } // third row of pizza toppings 
    
    
  }// end  if
  //////////////////////////////////////
 
   
    
    
  fill(235, 176, 66)
  
    ellipse(50 + mouseX, 275 + mouseY, 120, 120); // crust
  
  fill(235, 210, 101);
  
  ellipse (50 + mouseX, 275 + mouseY, 100, 100); //cheese
  
  
  var x = 25 ;
  while (x <= 75){
    
    fill(235, 89, 42);
     ellipse( x+ mouseX , 250 + mouseY,15,15);
    
    x = x+ 25;
  } //first row of toppings
  
  
  var x = 12;
  while (x <= 100){
    fill(235, 89, 42);
     ellipse( x+mouseX, 275 + mouseY,15,15);
    
    x = x+ 25;
  } // second row of pizza toppings
  
    
   var x = 25;
  while (x <= 75){
    fill(235, 89, 42);
     ellipse( x +mouseX , 300 + mouseY,15,15);
    
    x = x+ 25;
  } // third row of pizza toppings 
    
     
    
 
  
  
}