let duck;
let cam;
let movement = 0.01;

var panda;

function preload() {
  
  car = loadJSON("car.json");
  
}

function setup() {
  createCanvas(400, 400, WEBGL);
  
  
  fill(car.r, car.g, car.b);
  text(car.name, 10, 50);

   cam = createCamera();
  // set initial pan angle
  cam.pan(-0.4);
  
  
}

function draw() {
  background(60);

  
 
  
  
  
   // pan camera according to angle 'movement'
  cam.pan(movement);

  // every 100 frames, switch direction
  if (frameCount % 100 === 0) {
    movement *= -1;
  }
  
   ///// Sphere
  
  translate( 0, 0, 0);
    push();
   let dirX = 1;
  let dirY =  1;
    directionalLight(300, 0, 0, -dirX, -dirY, -1);
  rotateZ(frameCount * 0.01);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
  sphere(30);
  pop();
  
    ////// Shape: Cube
  
  translate(-125, -125, -150);
  
  push();
  ambientLight(200);
  ambientMaterial(60, 180, 94);
  rotateZ(frameCount * 0.02);
  rotateX(frameCount * 0.02);
  rotateY(frameCount * 0.02);
  box(60, 60, 60);
  pop();

  
 ///// Shape: 8 sided 
  
   translate(0, 260, 100);
  
  push();
  ambientLight(200);
  normalMaterial();
  rotateZ(frameCount * 0.01);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
  beginShape();
vertex(-10, 10);
vertex(0, 35);
vertex(10, 10);
vertex(35, 0);
vertex(10, -8);
vertex(0, -35);
vertex(-10, -8);
vertex(-35, 0);
endShape();
  pop();
  
}